namespace DotNetNuke.Modules.Events
{
    using DotNetNuke.UI;
    using DotNetNuke.Services.Exceptions;
    using System.Diagnostics;
    using DotNetNuke.Entities.Users;
    using System.Web.UI;
    using System.Drawing;
    using DotNetNuke.Framework;
    using Microsoft.VisualBasic;
    using System.Configuration;
    using System.Web.UI.WebControls;
    using System.Collections;
    using DotNetNuke.Common.Utilities;
    using System.Web;
    using DotNetNuke.Common;
    using System.Web.UI.HtmlControls;
    using DotNetNuke.Services.Localization;
    using System.Data;
    using System;
    using DotNetNuke.Data;
    using DotNetNuke;

    public partial class EventRSS
    {
    }
}
