using DotNetNuke.UI;
using DotNetNuke.Services.Exceptions;
using System.Diagnostics;
using DotNetNuke.Entities.Users;
using System.Web.UI;
using System.Drawing;
using DotNetNuke.Framework;
using Microsoft.VisualBasic;
using System.Configuration;
using System.Web.UI.WebControls;
using System.Collections;
using DotNetNuke.Common.Utilities;
using System.Web;
using DotNetNuke.Common;
using System.Web.UI.HtmlControls;
using DotNetNuke.Services.Localization;
using System.Data;
using System;
using DotNetNuke.Data;
using DotNetNuke;

namespace DotNetNuke.Modules.Events
{

    public partial class EventIPN
    {

        ///<summary>
        ///Form1 control.
        ///</summary>
        ///<remarks>
        ///Auto-generated field.
        ///To modify move field declaration from designer file to code-behind file.
        ///</remarks>
        protected global::System.Web.UI.HtmlControls.HtmlForm Form1;
    }
}


